int bookContainsAuthor(BookData * b, const char * word){
	char * token;
	const char * break_character = " ";
	
	//criar uma cópia de b->authors
	char authors_copy[MAX_AUTHORS];
	for(int i = 0; b->authors[i]!='\0'; i++)authors_copy[i] = b->authors[i];
	
	//passar as vírgulas a espaços
	for(int i = 0; authors_copy[i] != '\0'; i++)
		if(authors_copy[i] = ',')
			authors_copy[i] = ' ';
	
	//uniformizar a string
	separatorUnify(authors_copy);
	
	token = strtok(authors_copy, break_character);
	while(token != NULL){
		if(strcmp_ic == 0)return 1;
		token = strtok(NULL, break_character);
	}
	
	return 0;
}
