int fillBookData(BookData * b, const char * line){
	char * unsplit_line;
	
	//fazer uma cópia de line
	char line_copy[LINE_LEN];
	char string_aux[LINE_LEN];
	strcpy(line_copy, line);
	
	unsplit_line = splitField(line_copy); //obtenção do título
	if(!unsplit_line)return 0;			  //verificação do pointer
	separatorUnify(line_copy);
	
	strcpy(b->title, line_copy);		  //preenchimento do título
	
	int i;	  							  //preenchimento de line_copy com o resto da linha
	for(i = 0; unsplit_line[i] != '\0'; i++)line_copy[i] = unsplit_line[i];

	
	unsplit_line = splitField(line_copy); //preenchimento do isbn
	if(!unsplit_line)return 0;
	separatorUnify(line_copy);
	strcpy(b->isbn,line_copy);

	for(i = 0; unsplit_line[i] != '\0'; i++)line_copy[i] = unsplit_line[i];
	
	unsplit_line = splitField(line_copy); //avançar sem copiar o 3º campo da linha
	if(!unsplit_line)return 0;
	for(i = 0; unsplit_line[i] != '\0'; i++)line_copy[i] = unsplit_line[i];
	
	unsplit_line = splitField(line_copy); //preenchimento do authors
	if(!unsplit_line)return 0;
	separatorUnify(line_copy);
	strcpy(b->authors,line_copy);

	for(i = 0; unsplit_line[i] != '\0'; i++)line_copy[i] = unsplit_line[i];
	
	
	unsplit_line = splitField(line_copy); //preenchimento do publisher
	if(!unsplit_line)return 0;
	separatorUnify(line_copy);
	strcpy(b->publisher,line_copy);
	
	for(i = 0; unsplit_line[i] != '\0'; i++)line_copy[i] = unsplit_line[i];
	
	return 1;
}
