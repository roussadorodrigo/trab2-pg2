void collSortTitle(Collection * col){
	if(col == NULL || col->count == 0)printf("ERRO - a collection não existe ou está vazia!");
	else{qsort(col->books, col->count, sizeof(BookData), (int (*) (const void *, const void *))title_cmp);}	
}
