int collAddBook(const char * line, void * context){
	
	Collection * p = (Collection *)context; //ponteiro auxiliar (para a collection)
	
	//verificar se há espaço para o novo elemento
	if(p->count == MAX_BOOKS)return 0;
	
	//verificar se a informação é válida
	if(fillBookData(&(p->books[p->count]), line) == 0)return 0;
	//preencher a estrutura com o novo elemento
	p->refs[p->count] = NULL;
	p->count++;
	return 1;
}
