void collSortRefIsbn(Collection * col){
	//iniciar o array refs (com a ordem do array books)
	for(int i = 0; i < col->count; i++){
		col->refs[i] = &(col->books[i]);
	}
	
	//ordenar o array refs
	qsort(col->refs, col->count, sizeof(BookData *), (int (*) (const void *, const void *))isbn_cmp);
}
