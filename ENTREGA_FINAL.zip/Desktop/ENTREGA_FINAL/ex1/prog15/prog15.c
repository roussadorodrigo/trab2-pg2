#include <stdio.h>
#include <ctype.h>
#include <string.h>

#include "books.h"

int main(int argc, char * argv[]){
	int n_lines = processFile(argv[1], lineFilterPrint, argv[2]);
	if(n_lines == -1)
		printf("Não foram apresentadas linhas do ficheiro!\n");
	else
		printf("Número de linhas apresentadas: %d\n", n_lines);
}
