int linePrintRaw(const char * line, void * context){
	printf("%s", line);
	return 1;
}
