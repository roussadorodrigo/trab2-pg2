#include <stdio.h>

#include "books.h"

int main(int argc, char * argv[]){
	processFile(argv[1], linePrintRaw, NULL);	
}
